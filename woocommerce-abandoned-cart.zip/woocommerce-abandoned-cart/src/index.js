import './wcal-blocks-gdpr-email-compliance';
